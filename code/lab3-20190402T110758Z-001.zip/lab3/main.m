s1 = audioinfo('cut/dwa_1.wav');
s1